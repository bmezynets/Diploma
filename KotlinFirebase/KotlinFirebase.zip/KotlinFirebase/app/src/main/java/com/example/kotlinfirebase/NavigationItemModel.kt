package com.example.kotlinfirebase

class NavigationItemModel(var icon: Int, var title: String) {
}